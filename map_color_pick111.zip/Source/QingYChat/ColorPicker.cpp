// Fill out your copyright notice in the Description page of Project Settings.


#include "ColorPicker.h"

#include "Widgets/Layout/SBorder.h"
#include "Widgets/Colors/SColorPicker.h"
/*#include "Widgets/Images/SImage.h"*/

#define LOCTEXT_NAMESPACE "UMG"

UColorPicker::UColorPicker()
{

}

/*


*/

TSharedRef<SWidget> UColorPicker::RebuildWidget()
{
	//SColorPicker
	MyColorPickerBorder = SNew(SBorder);

	return MyColorPickerBorder.ToSharedRef();

}

#if WITH_EDITOR
const FText UColorPicker::GetPaletteCategory()
{
	
	return LOCTEXT("ColoPicker", "ColoPicker");

}

void UColorPicker::OpenColorPicker(FLinearColor InitColor)
{
	
	MyColorPicker = SNew(SColorPicker)
		.TargetColorAttribute(FLinearColor(InitColor))
		.UseAlpha(true)
		.OnlyRefreshOnMouseUp(false)
		.OnlyRefreshOnOk(false)
		.ExpandAdvancedSection(true)
		.OnInteractivePickBegin(BIND_UOBJECT_DELEGATE(FSimpleDelegate, OnInteractivePickBegin))
		.OnInteractivePickEnd(BIND_UOBJECT_DELEGATE(FSimpleDelegate, OnInteractivePickEnd))
		.OnColorCommitted(BIND_UOBJECT_DELEGATE(FOnLinearColorValueChanged, UpdateColor))
		;


	if (MyColorPickerBorder.IsValid())
	{
		MyColorPickerBorder->SetContent(MyColorPicker.ToSharedRef());
	}
	
}

void UColorPicker::OnInteractivePickBegin()
{





}

void UColorPicker::OnInteractivePickEnd()
{


}

void UColorPicker::UpdateColor(FLinearColor NewColor)
{

	ChangeColor.Broadcast(NewColor);
}

#endif


#undef LOCTEXT_NAMESPACE
