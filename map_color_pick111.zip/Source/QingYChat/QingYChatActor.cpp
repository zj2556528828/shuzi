#include "QingYChatActor.h"
#include <string>
using namespace std;

AQingYChatActor::AQingYChatActor()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
}

void AQingYChatActor::BeginPlay()
{
	Super::BeginPlay();
}

void AQingYChatActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

unsigned char ToHex(unsigned char x)
{
	return  x > 9 ? x + 55 : x + 48;
}

string UrlEncode(string str)
{
	string strTemp = "";
	size_t length = str.length();
	for (size_t i = 0; i < length; i++)
	{
		if (isalnum((unsigned char)str[i]) || (str[i] == '-') || (str[i] == '_') || (str[i] == '.') || (str[i] == '~'))
		{
			strTemp += str[i];
		}
		else if (str[i] == ' ')
		{
			strTemp += "+";
		}
		else
		{
			strTemp += '%';
			strTemp += ToHex((unsigned char)str[i] >> 4);
			strTemp += ToHex((unsigned char)str[i] % 16);
		}
	}
	return strTemp;
}

void stringReplace(string& src, const string s1, const string s2)
{
	string::size_type pos = 0;
	while ((pos = src.find(s1, pos)) != string::npos)
	{
		src.replace(pos, s1.length(), s2);
		pos += s2.length();
	}
}

FString StrToUrlEncode(FString Input)
{
	string TextInput = TCHAR_TO_UTF8(*Input);
	string TextUrlEncode = UrlEncode(TextInput);
	stringReplace(TextUrlEncode, "+", "%20");
	stringReplace(TextUrlEncode, "*", "%2A");
	stringReplace(TextUrlEncode, "%7E", "~");
	FString UrlText = TextUrlEncode.c_str();
	return UrlText;
}

FString SplitValue(FString& Input, FString Symbol1, FString Symbol2, int32 IndexL, int32 IndexR)
{
	FString LeftS, RightS;
	Input.Split(Symbol1, &LeftS, &RightS);
	RightS.Split(Symbol2, &LeftS, &RightS);
	Input = Symbol2 + RightS;
	LeftS = LeftS.RightChop(IndexL);
	LeftS = LeftS.LeftChop(IndexR);
	return LeftS;
}

void AQingYChatActor::QingYChat(FString Content, const FSingleCastQingYChatComplete& Complete)
{
	AQingYChatActor* MyQingYChatActor = NewObject<AQingYChatActor>(StaticClass());
	MyQingYChatActor->SingleCastQingYChatComplete = Complete;
	MyQingYChatActor->QingYChatUrl(Content);
}

void AQingYChatActor::QingYChatUrl(FString Content)
{
	FString Url = "http://api.qingyunke.com/api.php?key=free&appid=0&msg=" + StrToUrlEncode(Content);
	TSharedRef<IHttpRequest, ESPMode::ThreadSafe> HttpRequest = FHttpModule::Get().CreateRequest();
	HttpRequest->SetVerb("GET");
	HttpRequest->SetURL(Url);
	HttpRequest->SetTimeout(5.0f);
	HttpRequest->OnProcessRequestComplete().BindUObject(this, &AQingYChatActor::QingYChatCallback);
	HttpRequest->ProcessRequest();
}

void AQingYChatActor::QingYChatCallback(FHttpRequestPtr Request, FHttpResponsePtr Response, bool WasSuccessful)
{
	if (Response.IsValid() && Response->GetResponseCode() == 200)
	{
		FString QingYAnswer = Response->GetContentAsString();
		QingYAnswer = SplitValue(QingYAnswer, "content", "\"}", 3, 0);
		QingYChatAnswerSingleCast(QingYAnswer);
	}
}

void AQingYChatActor::QingYChatAnswerSingleCast(FString Answer) const
{
	SingleCastQingYChatComplete.ExecuteIfBound(Answer);
	QingYChatComplete.Broadcast(Answer);
}