#pragma once
#include "CoreMinimal.h"
#include "Http.h"
#include "GameFramework/Actor.h"
#include "QingYChatActor.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FQingYChatComplete, FString, Answer);
DECLARE_DYNAMIC_DELEGATE_OneParam(FSingleCastQingYChatComplete, FString, Answer);

UCLASS()
class QINGYCHAT_API AQingYChatActor : public AActor
{
	GENERATED_BODY()

public:
	// Sets default values for this actor's properties
	AQingYChatActor();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	FQingYChatComplete QingYChatComplete;
	FSingleCastQingYChatComplete SingleCastQingYChatComplete;

	UFUNCTION(BlueprintCallable, Category = "MyFunction")
		void QingYChat(FString Content, const FSingleCastQingYChatComplete& Complete);

	void QingYChatUrl(FString Content);
	void QingYChatCallback(FHttpRequestPtr Request, FHttpResponsePtr Response, bool WasSuccessful);
	void QingYChatAnswerSingleCast(FString  Answer) const;
};
