// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/Widget.h"
#include "ColorPicker.generated.h"

/**
 * 
 */
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FChangeColorDelagate, FLinearColor, NewColor);
UCLASS()
class QINGYCHAT_API UColorPicker : public UWidget
{
	GENERATED_BODY()

public:
	UColorPicker();
	TSharedPtr<SBorder> MyColorPickerBorder;
	virtual TSharedRef<SWidget> RebuildWidget() override;


#if WITH_EDITOR
	virtual const FText GetPaletteCategory() override;

#endif;
public:
	UPROPERTY(BlueprintAssignable,Category="ColorPicker")
	FChangeColorDelagate ChangeColor;
public:
	UFUNCTION( BlueprintCallable,Category="ColorPicker")
	void OpenColorPicker(FLinearColor InitColor);
	void OnInteractivePickBegin();
	void OnInteractivePickEnd();
	void UpdateColor(FLinearColor NewColor);
private:
	TSharedPtr<class SColorPicker > MyColorPicker;
};